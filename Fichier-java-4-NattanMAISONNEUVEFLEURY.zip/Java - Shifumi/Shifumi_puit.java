import java.util.Scanner;

public class Shifumi_puit {

	public static void main(String[] args) {

		System.out.println("Voici les règles du jeu:"); // afficher la phrase ...
		System.out.println("Feuille bat la pierre et le puits"); // afficher la phrase ...
		System.out.println("Pierre bat les ciseaux"); // afficher la phrase ...
		System.out.println("Ciseaux bat la feuille"); // afficher la phrase ...
		System.out.println("Puit bat la pierre et le ciseau"); // afficher la phrase ...
		System.out.println("Égalité si deux éléments similaires"); // afficher la phrase ...

		Scanner sc = new Scanner(System.in); // ligne qui permet de pouvoir récupérer les saisies utilisateur

		int nbpoints; // variable qui va stocker le nombre de points pour gagner
		char chjoueur; // variable qui va stocker le choix du joueur
		char chOrdi; // variable qui va stocker le choix de l'ordinateur
		int aleatoire; // variable qui va stocker le nombre aléatoire
		boolean rejouer = true; // variable qui va permettre de rejouer

		while (rejouer) { // tant que rejouer est vrai

			int scoreOrdi = 0; // variable qui va stocker le score de l'ordinateur
			int scoreJoueur = 0; // variable qui va stocker le score du joueur

			do { // boucle qui permet de vérifier que le nombre de points est correct
				System.out.println("En combien de points se déroule la partie ? (3, 5 ou 10)"); // afficher la question ...
				nbpoints = sc.nextInt(); // lire le nombre de points
				System.out.println("Vous avez saisi : " + nbpoints); // afficher le nombre de points ...
			} while (nbpoints != 3 && nbpoints != 5 && nbpoints != 10); // tant que le nombre de points n'est pas correct

			while (scoreJoueur < nbpoints && scoreOrdi < nbpoints) { // tant que le score du joueur et de l'ordinateur est inférieur au nombre de points

				do { // boucle qui permet de vérifier que le choix du joueur est correct
					System.out.println("Choisissez pierre (p), feuille (f), ciseau (c), puits (t)"); // afficher la question ...
					chjoueur = sc.next().charAt(0); // lire le choix du joueur
					System.out.println("Vous avez saisi : " + chjoueur); // afficher le choix du joueur ...
				} while (chjoueur != 'p' && chjoueur != 'c' && chjoueur != 'f' && chjoueur != 't'); // tant que le choix du joueur n'est pas correct

				aleatoire = (int) (Math.random() * 4) + 1; // générer un nombre aléatoire entre 1 et 4

				if (aleatoire == 1) { // si le nombre aléatoire est 1
					chOrdi = 'p'; // alors l'ordinateur choisit pierre
				} else if (aleatoire == 2) { // si le nombre aléatoire est 2
					chOrdi = 'f'; // alors l'ordinateur choisit feuille
				} else if (aleatoire == 3) { // si le nombre aléatoire est 3
					chOrdi = 't'; // alors l'ordinateur choisit puits
				} else { // sinon
					chOrdi = 'c'; // alors l'ordinateur choisit ciseaux
				} 

				System.out.println("L'ordinateur a choisi..."); // afficher la phrase ...
				try {
					Thread.sleep(3000); // pause de 3 secondes pour le suspense
				} catch (InterruptedException e) { 
					e.printStackTrace(); 
				}
				System.out.println("Fin du suspense !"); // afficher la phrase ...
				System.out.println("Choix de l'ordinateur : " + chOrdi); // afficher le choix de l'ordinateur ...

				if (chjoueur == chOrdi) { // si le choix du joueur est égal au choix de l'ordinateur
					System.out.println("Égalité !"); // afficher la phrase ...
				} else if ((chjoueur == 'p' && chOrdi == 'c') || // sinon si le choix du joueur est pierre et le choix de l'ordinateur est ciseaux
						   (chjoueur == 'f' && chOrdi == 't') || // ou si le choix du joueur est feuille et le choix de l'ordinateur est puits
						   (chjoueur == 'f' && chOrdi == 'p') || // ou si le choix du joueur est feuille et le choix de l'ordinateur est pierre
						   (chjoueur == 't' && chOrdi == 'p') || // ou si le choix du joueur est puits et le choix de l'ordinateur est pierre
						   (chjoueur == 't' && chOrdi == 'c') || // ou si le choix du joueur est puits et le choix de l'ordinateur est ciseaux
						   (chjoueur == 'c' && chOrdi == 'f')) { // ou si le choix du joueur est ciseaux et le choix de l'ordinateur est feuille
					System.out.println("Vous gagnez !"); // afficher la phrase ...
					scoreJoueur++; // incrémenter le score du joueur
				} else { // sinon
					System.out.println("L'ordinateur gagne !"); // afficher la phrase ...
					scoreOrdi++; // incrémenter le score de l'ordinateur
				}

				System.out.println("Score : Joueur " + scoreJoueur + " - Score ordi : " + scoreOrdi); // afficher le score ...
			}

			System.out.println("Voulez-vous rejouer ? (o/n)"); // afficher la question ...
			char reponse = sc.next().charAt(0); // lire la réponse de l'utilisateur
			rejouer = (reponse == 'o'); // si la réponse est 'o' alors rejouer est vrai sinon rejouer est faux
		}

		sc.close(); // fermer le scanner
	}
}