import java.util.Scanner;

public class ShifumiClassique {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub

				/*
				 * La classe principale pour le jeu Shifumi
				 * Ce programme va simuler un jeu contre l'ordinateur avec des régles classiques.
				 * Règles:
				 * Le papier bat la pierre
				 * La pierre bat le ciseau
				 * Le ciseau bat le papier
				 * Egalité si pareil
				 * 
				 * @author Nattan
				 * @version 1.0
				 */

				System.out.println("Voici les règles du jeu:"); // afficher la phrase ...
				System.out.println("Feuille bat la pierre"); // afficher la phrase ...
				System.out.println("Pierre bat les ciseaux"); // afficher la phrase ...
				System.out.println("Ciseaux bat la feuille"); // afficher la phrase ...
				System.out.println("égalité si deux élément similaire"); // afficher la phrase ...
				
				Scanner sc = new Scanner(System.in);
				
				//VARIABLES
				
				int nbpoints; // variable qui va stocker le nombre de points pour gagner
				char chjoueur; // variable qui va stocker le choix du joueur
				char chOrdi; // variable qui va stocker le choix de l'ordinateur
				int aleatoire; // variable qui va stocker le nombre aléatoire
		    	int scoreOrdi = 0; // variable qui va stocker le score de l'ordinateur
		    	int scoreJoueur = 0; // variable qui va stocker le score du joueur
		    	boolean rejouer = true; // variable qui va permettre de rejouer

		    	//étapes 7 
		    	
		    	while (rejouer) {  //tant que rejouer est vrai
		    		
		    		scoreOrdi = 0; // réinitialiser le score de l'ordinateur
		    		scoreJoueur = 0; // réinitialiser le score du joueur
				
				//étapes 1 
				
				do { // boucle qui permet de vérifier que le nombre de points est correct
					System.out.println("En combien de points se déroule la partie ? (3, 5 ou10)"); // afficher la question ...
					nbpoints= sc.nextInt(); // lire le nombre de points
					System.out.println("Vouz avez saisie : "+nbpoints); // afficher le nombre de points ...
					}while(nbpoints != 3 && nbpoints != 5 && nbpoints != 10); // tant que le nombre de points n'est pas correct
				
				//étapes 2 
				
				while (scoreJoueur < nbpoints && scoreOrdi < nbpoints) { // tant que le score du joueur et de l'ordinateur est inférieur au nombre de points
				
				do { // boucle qui permet de vérifier que le choix du joueur est correct
					System.out.println("Choisissez pierre, feuille, ciseau"); // afficher la question ...
					chjoueur= sc.next().charAt(0); // lire le choix du joueur
					System.out.println("Vous avez saisie : "+chjoueur); // afficher le choix du joueur ...
					}while(chjoueur != 'p' && chjoueur != 'c' && chjoueur != 'f'); // tant que le choix du joueur n'est pas correct

				//étapes 3 
				
				aleatoire= (int)(Math.random()*3) +1; // générer un nombre aléatoire entre 1 et 3
				
				if (aleatoire==1) { // si le nombre aléatoire est 1
			    	chOrdi='¤' ; // alors l'ordinateur choisit pierre
			    }
			    else if (aleatoire==2) { // si le nombre aléatoire est 2
			    	chOrdi='_' ; // alors l'ordinateur choisit feuille
			    }
			    else   { // sinon
			    	chOrdi='>' ; // alors l'ordinateur choisit ciseaux
			    }
				
				//étapes 4
				
				System.out.println("l'ordinateur a choisi..."); // afficher la phrase ...

		 	   //try catch permet de continuer le pragramme en cas de probleme de la fonction thread 

		 	    try {
		 	    	Thread.sleep(3000); // pause de 3 secondes pour le suspense
		 	    	} catch (InterruptedException e) {
		 	    	e.printStackTrace();
		 	    	}

			 	    System.out.println("fin du suspense !"); // afficher la phrase ...
			 	    System.out.println(chOrdi); // afficher le choix de l'ordinateur ...
		 	    
		 	    	//étapes 5
		 	    
			 	   System.out.println("Choix de l'ordinateur : " + chOrdi); // afficher le choix de l'ordinateur ...
			
				    
			
			 	  if (chjoueur == chOrdi) { // si le choix du joueur est égal au choix de l'ordinateur
			 		    System.out.println("Égalité !"); // afficher la phrase ...
			 		} else if ((chjoueur == '¤' && chOrdi == '>') || // sinon si le choix du joueur est pierre et le choix de l'ordinateur est ciseaux
			 		           (chjoueur == '-' && chOrdi == '¤') || // ou si le choix du joueur est feuille et le choix de l'ordinateur est pierre
			 		           (chjoueur == '>' && chOrdi == '_')) { // ou si le choix du joueur est ciseaux et le choix de l'ordinateur est feuille
			 		    System.out.println("Vous gagnez !"); // afficher la phrase ...
			 		    scoreJoueur += 1; // incrémenter le score du joueur
			 		} else { // sinon
			 		    System.out.println("L'ordinateur gagne !"); // afficher la phrase ...
			 		    scoreOrdi += 1; // incrémenter le score de l'ordinateur
			 		}


			    	//affichage du score 

		 	  		System.out.println("Score : Joueur " + scoreJoueur + " - Score ordi : " + scoreOrdi); // afficher le score ...
				}
				System.out.println("Voulez-vous rejouer ? (o/n)"); // afficher la question ...
			    char reponse = sc.next().charAt(0); // lire la réponse de l'utilisateur
			    rejouer = (reponse == 'o'); // si la réponse est 'o' alors rejouer est vrai sinon rejouer est faux
				}
			sc.close(); // fermer le scanner
	}
}
