import java.util.Scanner;

public class accueil_shifumi {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Bienvenue dans le jeu Shifumi !"); // afficher la phrase ...
        System.out.println("Souhaitez-vous jouer avec la variante du puits ? (p/s)"); // afficher la question ...
        char choix = sc.next().charAt(0); // lire le choix de l'utilisateur

        if (choix == 'p') { // si le choix est 'p'
            Shifumi_puit.main(null); // alors utiliser le code de la page shifumi_puit
        } else { // sinon
            ShifumiClassique.main(null); // alors utiliser le code de la page shifumiClassique
        }

        sc.close(); // fermer le scanner
    }
}
