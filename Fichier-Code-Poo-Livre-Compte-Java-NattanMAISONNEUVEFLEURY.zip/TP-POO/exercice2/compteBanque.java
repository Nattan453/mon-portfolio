package exercice2;

public class compteBanque {

    // Classe Client
    public static class Client {

        private String CIN;
        private String Nom;
        private String Prenom;
        private int tel;

        // Constructeur de la classe Client
        public Client(String CIN, String Nom, String Prenom, int tel) {
            this.CIN = CIN;
            this.Nom = Nom;
            this.Prenom = Prenom;
            this.tel = tel;
        }

        // Getters et Setters pour chaque attribut
        public String getCIN() {
            return CIN;
        }

        public void setCIN(String CIN) {
            this.CIN = CIN;
        }

        public String getNom() {
            return Nom;
        }

        public void setNom(String Nom) {
            this.Nom = Nom;
        }

        public String getPrenom() {
            return Prenom;
        }

        public void setPrenom(String Prenom) {
            this.Prenom = Prenom;
        }

        public int getTel() {
            return tel;
        }

        public void setTel(int tel) {
            this.tel = tel;
        }

        // Méthode pour afficher les informations du client
        public void afficherClient() {
            System.out.println("Client : ");
            System.out.println("CIN : " + CIN);
            System.out.println("Nom : " + Nom);
            System.out.println("Prénom : " + Prenom);
            System.out.println("Tel : " + tel);
        }
    }

    // Classe compte
    public static class compte {

        // Attributs
        private static int compteur = 0; // Compteur pour générer des numéros de comptes uniques
        private Client client; // Lien avec la classe Client
        private final int nbCompte; // Numéro unique pour chaque compte (en lecture seule)
        private double solde; // Solde du compte (en lecture seule)

        // Constructeur avec solde et client
        public compte(Client client, double solde) {
            this.client = client;
            this.solde = solde;

            // Incrémentation du compteur pour générer un numéro unique
            this.nbCompte = ++compteur;
        }

        // Méthodes d'accès pour le client
        public Client getClient() {
            return client;
        }

        public void setClient(Client client) {
            this.client = client;
        }

        // Getter pour le solde (en lecture seule)
        public double getSolde() {
            return solde;
        }

        // Getter pour Numéro de compte (en lecture seule)
        public int getNbCompte() {
            return nbCompte;
        }

        // Méthode pour créditer le compte
        public void crediter(double somme) {
            solde += somme;
            System.out.println("\n*************************");
            System.out.println("Donner le montant à déposer : " + somme);
            System.out.println("Opération bien effectuée\n");
            afficherDetails();
        }

        // Méthode pour débiter le compte
        public void debiter(double somme) {
            solde -= somme;
            System.out.println("\n*************************");
            System.out.println("Donner le montant à retirer : " + somme);
            System.out.println("Opération bien effectuée\n");
            afficherDetails();
        }

        // Méthode pour afficher les détails du compte
        public void afficherDetails() {
            System.out.println("Détails du compte :");
            System.out.println("********************");
            System.out.println("Numéro de compte : " + nbCompte);
            System.out.println("Solde de compte : " + solde);
            client.afficherClient(); // Affiche les détails du client
        }

        // Méthode main pour tester les fonctionnalités
        public static void main(String[] args) {

            Client client1 = new Client("EE111222", "Salim", "Omar", 611111111);// Création d'un client

            compte compte1 = new compte(client1, 0.0);// Création d'un compte pour ce client avec un solde initial de 0

            compte1.afficherDetails(); // affichage détail du compte

            compte1.crediter(5000);// Crédits de 5000
            compte1.debiter(1000);// Débiter 1000
        }
    }

}
