package exercice1;

import java.util.Scanner;

public class livre {

    private String titre; // attributs privée
    private String auteur; // attributs privée
    private int prix; // attributs privée

    public livre(String titre, String auteur, int prix) {
        this.titre = titre; // constructeur
        this.auteur = auteur; // constructeur
        this.prix = prix; // constructeur
    }

    public String getTitre() {
        return titre; // retourner variable
    }

    public String getAuteur() {
        return auteur; // retourner variable
    }

    public int getPrix() {
        return prix; // retourner variable
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public void setAuteur(String auteur) {
        this.auteur = auteur;
    }

    public void setPrix(int prix) {
        if (prix >= 0) { // si prix supérieur ou égal à 0 pour forcer a avoir un nombre positif
            this.prix = prix;
        } else { // sinon
            System.out.println("Le prix ne peut pas être négatif."); // ...
        }
    }

    public void afficher() {
        System.out.println("Titre : " + titre + ", Auteur : " + auteur + ", Prix : " + prix + " euros");
    }

    public static void main(String[] args) {
        String choix = "o";
        int livre = 1;

        Scanner scanner = new Scanner(System.in);

        do { // système pour rajouter un livre
            System.out.print("Donner le titre : ");
            String titreSaisie = scanner.nextLine(); // rentrer la valeur dans la variable
            System.out.print("Donner l'auteur : ");
            String auteurSaisie = scanner.nextLine(); // rentrer la valeur dans la variable
            System.out.print("Donner le prix : ");
            int prixSaisie = scanner.nextInt(); // rentrer la valeur dans la variable
            scanner.nextLine();

            livre monLivre = new livre(titreSaisie, auteurSaisie, prixSaisie); // intégrer monLivre dans livre
            // titre = titreSaisie, auteur = auteurSaisie...

            System.out.println("livre " + livre + " :");
            monLivre.afficher(); // afficher monLivre (donc afficher livre)

            System.out.print("Voulez-vous enregistrer un deuxième livre ? (n = non / o = Oui) ");
            choix = scanner.nextLine();
            livre = livre + 1;

        } while (choix.equals("o"));
    }
}
