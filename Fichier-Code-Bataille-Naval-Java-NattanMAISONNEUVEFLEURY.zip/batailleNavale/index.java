import java.util.Scanner;

public class index {

    static void affichagetab(int[][] tab, int nbcase) {
        System.out.print("  "); //espace pour que les lignes soient bien alignées
        for (int indiceColonne = 0; indiceColonne < nbcase; indiceColonne++) { //pour la variable indiceColonne tant que indiceColonne est inférieur a nbcase. indiceColonne + 1 a chaque tour
            System.out.print(indiceColonne + " ");//afficher un espace après la variable
        }
        System.out.println(); //sert a passer a ligne suivante

        for (int i = 0; i < nbcase; i++) { //pour i tant que i inférieur à nbcase. i + 1 a chaque tour
            System.out.print(i + " "); // Numéro de ligne
            for (int j = 0; j < nbcase; j++) { //pour j tant que j inférieur à nbcase. j + 1 a chaque tour
                if (tab[i][j] == 1) { //la variable s'initialise a 1
                    System.out.print("O "); // pion du joueur
                } else { //sinon
                    System.out.print("~ "); // case vide
                }
            }
            System.out.println();//sert a passer a ligne suivante
        }
    }

    static void affichageCache(int[][] tab, int nbcase) {
    System.out.print("  "); //espace pour que les lignes soient bien alignées
    for (int indiceColonne = 0; indiceColonne < nbcase; indiceColonne++) { //pour la variable indiceColonne tant que indiceColonne est inférieur a nbcase. indiceColonne + 1 a chaque tour
        System.out.print(indiceColonne + " ");//afficher un espace après la variable
    }
    System.out.println();//sert a passer a ligne suivante

    for (int i = 0; i < nbcase; i++) {
        System.out.print(i + " "); // numéro de ligne
        for (int j = 0; j < nbcase; j++) { //pour j tant que j inférieur à nbcase. j + 1 a chaque tour
            if (tab[i][j] == 0) { //si la variable est égale à 0
                System.out.print("? "); // case non découverte
            } else if (tab[i][j] == 2) { //sinon si égale a 2
                System.out.print("O "); // case avec bateau
            } else if (tab[i][j] == 3) { //sinon si égale a 3
                System.out.print("X "); // case vide
            }
        }
        System.out.println();//sert a passer a ligne suivante
    }
}

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[][] tabjoueur = new int[5][5];
        int[][] tabordi = new int[5][5];
        int choixJoueurLigne = 0;
        int choixJoueurColonne = 0;
        int compteur = 0;
        int choixOrdiLigne = 0;
        int choixOrdiColonne = 0;
        boolean recommencer = true;

        while (recommencer) {

        // Initialisation du tableau joueur
        for (int i = 0; i < tabjoueur.length; i++) {
            for (int j = 0; j < tabjoueur[i].length; j++) {
                tabjoueur[i][j] = 0;
            }
        }

        // ETAPE 2 - Choix du joueur
        do {
            affichagetab(tabjoueur, 5);

            do {
                System.out.println("Sur quelle ligne voulez-vous placer votre pion ? (0 à 4)");
                choixJoueurLigne = sc.nextInt();

                System.out.println("Sur quelle colonne voulez-vous placer votre pion ? (0 à 4)");
                choixJoueurColonne = sc.nextInt();

                if (choixJoueurLigne < 0 || choixJoueurLigne > 4 || choixJoueurColonne < 0 || choixJoueurColonne > 4) {
                    System.out.println("Valeurs non comprises entre 0 et 4");
                } else if (tabjoueur[choixJoueurLigne][choixJoueurColonne] != 0) {
                    System.out.println("Case déjà prise.");
                }
            } while (
                choixJoueurLigne < 0 || choixJoueurLigne > 4 ||
                choixJoueurColonne < 0 || choixJoueurColonne > 4 ||
                tabjoueur[choixJoueurLigne][choixJoueurColonne] != 0
            );

            tabjoueur[choixJoueurLigne][choixJoueurColonne] = 1;
            System.out.println("Le pion a bien été placé");
            compteur++;
        } while (compteur != 5);

        // ETAPE 3 - Choix ordinateur
        compteur = 0;
        do {
            do {
                choixOrdiLigne = (int)(Math.random() * 5);
                choixOrdiColonne = (int)(Math.random() * 5);
            } while (tabordi[choixOrdiLigne][choixOrdiColonne] != 0);

            tabordi[choixOrdiLigne][choixOrdiColonne] = 1;
            compteur++;
        } while (compteur != 5);

        // Affichage final du tableau joueur
        System.out.println("\nTableau du joueur :");
        affichagetab(tabjoueur, 5);

        boolean finPartie = false; // Variable pour vérifier la fin de la partie
        boolean finPartieOrdi = false; // Variable pour vérifier la fin de la partie de l'ordi
        int nbPionTrouveJoueur = 0; // Compteur de pions trouvés par le joueur
        int nbPionTrouveOrdi = 0; // Compteur de pions trouvés par l'ordinateur

        while (!finPartie && !finPartieOrdi) { //   Tant que la partie n'est pas finie
            // ETAPE 6 - Tour du joueur
            System.out.println("\nÀ vous de jouer !"); // Tour du joueur
            affichageCache(tabordi, 5); // Affichage du tableau de l'ordi caché

            int tirLigne, tirColonne; // Coordonnées du tir du joueur
            do { // Demande des coordonnées tant que les valeurs ne sont pas correctes
                System.out.println("Sur quelle ligne voulez-vous tirer ? (0 à 4)"); // Demande des coordonnées
                tirLigne = sc.nextInt(); // Lecture de la ligne

                System.out.println("Sur quelle colonne voulez-vous tirer ? (0 à 4)"); // Demande des coordonnées
                tirColonne = sc.nextInt(); // Lecture de la colonne

                if (tirLigne < 0 || tirLigne > 4 || tirColonne < 0 || tirColonne > 4) { // Vérification des coordonnées
                    System.out.println("Valeurs non comprises entre 0 et 4 !"); // Message d'erreur
                }
            } while (tirLigne < 0 || tirLigne > 4 || tirColonne < 0 || tirColonne > 4); //  Vérification des coordonnées

            System.out.println("Tir en cours..."); // Message de tir
            try { // Pause de 2 secondes pour simuler le tir
                Thread.sleep(2000); // Pause de 2 secondes
            } catch (InterruptedException e) { // Gestion de l'exception
                e.printStackTrace(); // Affichage de l'exception
            }

            if (tabordi[tirLigne][tirColonne] == 0) { // Si le tir est un échec
                System.out.println("Raté !"); //    Message de raté
                tabordi[tirLigne][tirColonne] = 3; // Marquage de la case comme ratée
            } else if (tabordi[tirLigne][tirColonne] == 1) { // Si le tir est un succès
                System.out.println("Touché !"); // Message de touché
                tabordi[tirLigne][tirColonne] = 2; //   Marquage de la case comme touchée
                nbPionTrouveJoueur++; // Incrémentation du compteur de pions trouvés
            } else { // Si le tir est sur une case déjà découverte
                System.out.println("Tir à blanc (vous avez déjà tiré ici) !"); // Message de tir à blanc
            }

            System.out.println("\nTableau de l'ordinateur :"); // Affichage du tableau de l'ordi mis à jour
            affichageCache(tabordi, 5); //  Affichage du tableau de l'ordi caché mis à jour

            if (nbPionTrouveJoueur == 5) { // Si le joueur a trouvé tous les pions
                System.out.println("Bravo, vous avez trouvé tous les pions !"); // Message de victoire
                finPartie = true; // Fin de la partie
                break; // Sortie de la boucle
            }

            // ETAPE 7 - Tour de l’ordinateur
            System.out.println("\nTour de l'ordinateur..."); // Tour de l'ordinateur
            System.out.println("L'ordinateur réfléchit..."); // Message de réflexion

            int tirOrdiLigne, tirOrdiColonne; // Coordonnées du tir de l'ordinateur
            do { // Génération des coordonnées tant que les valeurs ne sont pas correctes
                tirOrdiLigne = (int)(Math.random() * 5); // Génération aléatoire de la ligne
                tirOrdiColonne = (int)(Math.random() * 5); // Génération aléatoire de la colonne
            } while (tabjoueur[tirOrdiLigne][tirOrdiColonne] != 0 && tabjoueur[tirOrdiLigne][tirOrdiColonne] != 1); // Vérification des coordonnées

            System.out.println("Tir en cours..."); // Message de tir
            try { // Pause de 2 secondes pour simuler le tir
                Thread.sleep(2000); // Pause de 2 secondes
            } catch (InterruptedException e) { //   Gestion de l'exception
                e.printStackTrace(); // Affichage de l'exception
            }

            if (tabjoueur[tirOrdiLigne][tirOrdiColonne] == 0) { // Si le tir est un échec
                System.out.println("L'ordinateur a tiré en (" + tirOrdiLigne + ", " + tirOrdiColonne + ") → Raté !"); // Message de raté
                tabjoueur[tirOrdiLigne][tirOrdiColonne] = 3; // Marquage de la case comme ratée
            } else if (tabjoueur[tirOrdiLigne][tirOrdiColonne] == 1) { //   Si le tir est un succès
                System.out.println("L'ordinateur a tiré en (" + tirOrdiLigne + ", " + tirOrdiColonne + ") → Touché !"); // Message de touché
                tabjoueur[tirOrdiLigne][tirOrdiColonne] = 2; // Marquage de la case comme touchée
                nbPionTrouveOrdi++; // Incrémentation du compteur de pions trouvés
            } else { // Si le tir est sur une case déjà découverte
                System.out.println("L'ordinateur a tiré sur une case déjà découverte !"); // Message de tir à blanc
            }

            System.out.println("\nTableau du joueur mis à jour :"); // Affichage du tableau du joueur mis à jour
            affichagetab(tabjoueur, 5); // Affichage du tableau du joueur mis à jour

            if (nbPionTrouveOrdi == 5) { // Si l'ordinateur a trouvé tous les pions
                System.out.println("L'ordinateur a trouvé tous vos pions... Vous avez perdu !"); // Message de défaite
                finPartieOrdi = true; //    Fin de la partie
                break; // Sortie de la boucle
            }
        }

                System.out.println("\n==============================");
        if (finPartie) {
            System.out.println("Félicitations, vous avez gagné la partie");
        } else if (finPartieOrdi) {
            System.out.println("L'ordinateur a gagné la partie");
        }
    
            System.out.println("Voulez-vous rejouer ? (o/n)");
            char rejouer = sc.next().toLowerCase().charAt(0);
            if (rejouer != 'o') {
                recommencer = false;
                System.out.println("fIN DU JEU");
            }
        }
        sc.close();
    }
}
