package exercice7;

import java.util.Scanner;

public class exercice7 {
    public static float valeurMaximale(float[] tab) { // déclaration de la fonction "valeurMaximale"
        float max = tab[0]; // initialisation de la variable max avec la première valeur du tableau
        for (int i = 1; i < tab.length; i++) { // boucle pour parcourir le tableau à partir du deuxième élément
            if (tab[i] > max) { // si l'élément courant est supérieur à max
                max = tab[i]; // mettre à jour max avec l'élément courant
            }
        }
        return max; // retourner la valeur maximale trouvée
    }

        public static float fonctionMoyenne(float[] tab) { // déclaration de la fonction "valeurMaximale"
        float moyenne = 0; // variable float somme initialiser a 0
        int i = 0; // variable entier i initialiser a 0


        while (i < tab.length) { // tant que i est inferieur a la longueur du tableau tab
            moyenne = moyenne + tab[i]; // moyenne prend moyenne + la case i du tableau tab
            i = i + 1; // i prend i + 1
        }


        return moyenne / tab.length; // retourne moyenne diviser par la longueur du tableau tab
    }

    public static void main(String[] args) { // méthode principale du programme
            Scanner sc = new Scanner(System.in);// balise permettant de pouvoir lire ce qu'écrit l'utilisateur
            float[] tab = new float[35]; // tableau de 35 notes
            int compteur2 = 0; // variable entier compteur2 initialiser a 0
            int compteur1 = 0; // variable entier compteur1 initialiser a 0
            float note = 0; // variable float note initialiser a 0
            float moyenne = 0; // variable float moyenne initialiser a 0
            float maxnote = 0; // variable float maxnote initialiser a 0

            while (compteur1 < 35){ // tant que compteur1 est inferieur a 35
                System.out.println("Veuillez sasir la note de l'élève n°" + (compteur1 + 1) + " (Note compris entre 0 et 20 !) (Pour les notes a virgule merci de mettre une virgule ex: 16,5) :"); // afficher la phrase ...
                note = sc.nextFloat(); // enregistre ce qu'a ecrit l'utilisateur 
                tab[compteur1] = note; // la case compteur1 du tableau tab prend la valeur de note
                compteur1 = compteur1 + 1; // compteur1 prend compteur1 + 1
            }

            moyenne = fonctionMoyenne(tab); // moyenne prend la valeur retourner par la fonction fonctionMoyenne

            maxnote = valeurMaximale(tab); // maxnote prend la valeur retourner par la fonction valeurMaximale

            System.out.println("La moyenne de la classe est de : " + moyenne); // afficher la phrase ...
            System.out.println("La meilleure note de la classe est de : " + maxnote); // afficher la phrase ...
        }
}
