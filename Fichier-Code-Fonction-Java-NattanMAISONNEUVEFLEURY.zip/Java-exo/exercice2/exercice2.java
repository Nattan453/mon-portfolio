package exercice2;

import java.util.Scanner;

public class exercice2 {
    public static void multiplication(){
        Scanner sc = new Scanner(System.in);// balise permettant de pouvoir lire ce qu'écrit l'utilisateur
        int n;// variable entier n
        int nb; // variable entier nb
        int i;// variable entier i
        int compteur = 1;// variable entier compteur initialiser a 1
        int recommencer;// variable entier recommencer

        do{//faire
                System.out.println("Ecrire un nombre");//afficher la phrase ...
                n = sc.nextInt();// enregistre se qu'a ecrit l'utilisateur

                System.out.println("jusqu'a combien voulez vous multiplier");//afficher la phrase ...
                nb = sc.nextInt();// enregistre se qu'a ecrit l'utilisateur

                System.out.println("table des" + n);//afficher la phrase ... + variable n

                do {
                    i = n*compteur;//i prend n * compteur
                    System.out.println(compteur + " * " + n + " = " + i);// afficher phrase + variable
                    compteur = compteur + 1;//compteur prend compteur + 1
                }while (compteur <= nb);//tant que compteur est inferieur ou égale à nb
            
            System.out.println("Voulez-vous relancer le programme ? (oui : 1 / non : 2)"); //afficher la phrase ...
            recommencer = sc.nextInt();// enregistre se qu'a ecrit l'utilisateur
        }while (recommencer == 1);//tant que recommencer est égal à 1
        

    }
    public static void main(String[] args) { // méthode principale du programme
        multiplication(); //appel de la procedure 
    }
}
