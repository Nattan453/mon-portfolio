package exercice4;

import java.util.Scanner;

public class exercice4 {
        public static void main(String[] args) { // méthode principale du programme
            Scanner sc = new Scanner(System.in);// balise permettant de pouvoir lire ce qu'écrit l'utilisateur
            float[] tab = new float[35]; // tableau de 35 notes
            int compteur2 = 0; // variable entier compteur2 initialiser a 0
            int compteur1 = 0; // variable entier compteur1 initialiser a 0
            float note = 0; // variable float note initialiser a 0
            float moyenne = 0; // variable float moyenne initialiser a 0
            float maxnote = 0; // variable float maxnote initialiser a 0

            while (compteur1 < 35){ // tant que compteur1 est inferieur a 35
                System.out.println("Veuillez sasir la note de l'élève n°" + (compteur1 + 1) + " (Note compris entre 0 et 20 !) (Pour les notes a virgule merci de mettre une virgule ex: 16,5) :"); // afficher la phrase ...
                note = sc.nextFloat(); // enregistre ce qu'a ecrit l'utilisateur 
                tab[compteur1] = note; // la case compteur1 du tableau tab prend la valeur de note
                moyenne = moyenne + note; // moyenne prend moyenne + note
                compteur1 = compteur1 + 1; // compteur1 prend compteur1 + 1
            }

            moyenne = moyenne / 35; // moyenne prend moyenne diviser par 35

            while (compteur2 < 35) { // tant que compteur2 est inferieur a 35
                if (tab[compteur2] > maxnote) { // si la case compteur2 du tableau tab est superieur a maxnote
                    maxnote = tab[compteur2]; // maxnote prend la case compteur2 du tableau tab
                }
                compteur2 = compteur2 + 1; // compteur2 prend compteur2 + 1
            }

            System.out.println("La moyenne de la classe est de : " + moyenne); // afficher la phrase ...
            System.out.println("La meilleure note de la classe est de : " + maxnote); // afficher la phrase ...
        }
}
