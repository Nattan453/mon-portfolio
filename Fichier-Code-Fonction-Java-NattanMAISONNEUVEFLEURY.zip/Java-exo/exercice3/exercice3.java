package exercice3;

import java.util.Scanner;

public class exercice3 {
    public static void factorielle() { // déclaration de la fonction "factoriser"
        Scanner sc = new Scanner(System.in);// balise permettant de pouvoir lire ce qu'écrit l'utilisateur
        int nombre; // variable entier nombre
        int total; // variable entier total
        int recommencer; //variable entier recommencer

        do { // faire
            System.out.println("Entrez un nombre à factoriser :"); // affiche la phrase ...
            nombre = sc.nextInt(); // enregistre se qu'a ecrit l'utilisateur

            total = 1; // initialise total a 1
            do { // faire
                total = total * nombre; // la variable total prend total * nombre
                nombre = nombre - 1; // la valeur nombre prend nombre -1
            } while (nombre > 1); // tant que nombre est supérieur à 1

            System.out.println("Résultat : " + total); // afficher la phrase ... + variable total

            System.out.println("Voulez-vous relancer le programme ? (oui : 1 / non : 2)"); // afficher la phrase
            recommencer = sc.nextInt(); // enregistre se qu'a ecrit l'utilisateur
        } while (recommencer == 1); // tant que nombre est égal à 1
    }

     public static void multiplication(){
        Scanner sc = new Scanner(System.in);// balise permettant de pouvoir lire ce qu'écrit l'utilisateur
        int n;// variable entier n
        int nb; // variable entier nb
        int i;// variable entier i
        int compteur = 1;// variable entier compteur initialiser a 1
        int recommencer;// variable entier recommencer

        do{//faire
                System.out.println("Ecrire un nombre");//afficher la phrase ...
                n = sc.nextInt();// enregistre se qu'a ecrit l'utilisateur

                System.out.println("jusqu'a combien voulez vous multiplier");//afficher la phrase ...
                nb = sc.nextInt();// enregistre se qu'a ecrit l'utilisateur

                System.out.println("table des" + n);//afficher la phrase ... + variable n

                do {
                    i = n*compteur;//i prend n * compteur
                    System.out.println(compteur + " * " + n + " = " + i);// afficher phrase + variable
                    compteur = compteur + 1;//compteur prend compteur + 1
                }while (compteur <= nb);//tant que compteur est inferieur ou égale à nb
            
            System.out.println("Voulez-vous relancer le programme ? (oui : 1 / non : 2)"); //afficher la phrase ...
            recommencer = sc.nextInt();// enregistre se qu'a ecrit l'utilisateur
        }while (recommencer == 1);//tant que recommencer est égal à 1
    }
    public static void main(String[] args) { // méthode principale du programme
        int relancer = 0;
        int choix = 0;

        Scanner sc = new Scanner(System.in);// balise permettant de pouvoir lire ce qu'écrit l'utilisateur
        do{
            System.out.println("Que souhaitez vous faire (1 : factorielle ; 2 : multiplication) ");
            choix = sc.nextInt();

            if (choix == 1){
                factorielle();
            }else if (choix == 2){
                multiplication();
            }else{
                System.out.println("erreur veuillez recommencer");
            }

            choix = 0;
            System.out.println("Voulez-vous relancer le programme ? (oui : 1 / non : 2)");
            relancer = sc.nextInt();
        }while(relancer == 1);
    }
}
