package exercice1;

import java.util.Scanner;

public class exercice1 {

    public static void factorielle() { // déclaration de la fonction "factoriser"
        Scanner sc = new Scanner(System.in);// balise permettant de pouvoir lire ce qu'écrit l'utilisateur
        int nombre; // variable entier nombre
        int total; // variable entier total
        int recommencer; //variable entier recommencer

        do { // faire
            System.out.println("Entrez un nombre à factoriser :"); // affiche la phrase ...
            nombre = sc.nextInt(); // enregistre se qu'a ecrit l'utilisateur

            total = 1; // initialise total a 1
            do { // faire
                total = total * nombre; // la variable total prend total * nombre
                nombre = nombre - 1; // la valeur nombre prend nombre -1
            } while (nombre > 1); // tant que nombre est supérieur à 1

            System.out.println("Résultat : " + total); // afficher la phrase ... + variable total

            System.out.println("Voulez-vous relancer le programme ? (oui : 1 / non : 2)"); // afficher la phrase
            recommencer = sc.nextInt(); // enregistre se qu'a ecrit l'utilisateur
        } while (recommencer == 1); // tant que nombre est égal à 1

        sc.close(); // fermer le scanner 
    }

    public static void main(String[] args) { // méthode principale du programme
        factorielle(); // appel de la fonction "factoriser"
    }
}
