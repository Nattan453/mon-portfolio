package exercice6;


public class exercice6 {
    public static float moyenne(float[] tab) { // déclaration de la fonction "valeurMaximale"
        float moyenne = 0; // variable float somme initialiser a 0
        int i = 0; // variable entier i initialiser a 0


        while (i < tab.length) { // tant que i est inferieur a la longueur du tableau tab
            moyenne = moyenne + tab[i]; // moyenne prend moyenne + la case i du tableau tab
            i = i + 1; // i prend i + 1
        }


        return moyenne / tab.length; // retourne moyenne diviser par la longueur du tableau tab
    }


    public static void main(String[] args) { // méthode principale du programme
    }
}
