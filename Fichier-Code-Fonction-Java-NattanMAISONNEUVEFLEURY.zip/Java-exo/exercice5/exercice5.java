package exercice5;


public class exercice5 {
    public static float valeurMaximale(float[] tab) { // déclaration de la fonction "valeurMaximale"
        float max = tab[0]; // initialisation de la variable max avec la première valeur du tableau
        for (int i = 1; i < tab.length; i++) { // boucle pour parcourir le tableau à partir du deuxième élément
            if (tab[i] > max) { // si l'élément courant est supérieur à max
                max = tab[i]; // mettre à jour max avec l'élément courant
            }
        }
        return max; // retourner la valeur maximale trouvée
    }


    public static void main(String[] args) { // méthode principale du programme
    }
}
