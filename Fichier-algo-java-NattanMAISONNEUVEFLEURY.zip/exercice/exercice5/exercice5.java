package exercice5;

import java.util.Scanner;

public class exercice5 {
    
    public static void main(String[] args) {
        float[] tab; // variable tableau tab
        int nb_note; // variable entier nb_note
        int compteur; // variable entier compteur
        int compteur2; // variable entier compteur2
        int i; // variable entier i
        float note; // variable réel note
        float total_note; // variable réel total_note
        float moyenne; // variable réel moyenne

        Scanner sc = new Scanner(System.in); //commande qui permet de faire écrire l'utilisateur et de garder en mémoire la réponse
        System.out.println("Saisir le nombre de notes"); //afiche la phrase
        nb_note = sc.nextInt(); //demande à l'utilisateur un nombre et l'enregistre dans la variable nb_note

        tab = new float[nb_note];  //intialise le tableau avec a variable nb_note
        compteur = 0; //intialise la variable compteur a 0
        total_note = 0; //intialise la variable total_note a 0

        do { // éxécuter....
            System.out.println("Entrer une note"); //afficher la phrase
            note = sc.nextFloat(); // demande à l'utilisateur un nombre et l'enregistre dans la variable note
            tab[compteur] = note; //dans le tableau, à l'indice de la valeur de compteur on ajoute la valeur de la variable note
            total_note = (total_note + note); //on additione note a total_note
            compteur = compteur + 1; //compteur prend +1
        } while (compteur != nb_note); //tant que compteur est différent de la valeur de nb_note

        moyenne = total_note / nb_note; //moyenne = total_note / nb_notes
        compteur2 = 0; //on initialise compteur de à 0

        for (i = 0; i < nb_note; i++){ //pour (initialisation de i a 0) i allant de 0 a nb_notes (pas de 1)
            if (tab[i] > moyenne) { //si tab indice i est supérieur à moyenne 
                compteur2 = compteur2 + 1; //alors compteur2 + 1
            } //fin si
        } //fin pour

        System.out.println("Le nombre de notes supérieur à la moyenne " + compteur2); //afficher la phrase...
    }
}
