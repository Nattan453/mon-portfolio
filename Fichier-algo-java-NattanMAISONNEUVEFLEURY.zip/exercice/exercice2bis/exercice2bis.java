package exercice2bis;

import javax.swing.JOptionPane; // Importation de la classe JOptionPane

public class exercice2bis {
    public static void main(String[] args) { 
        int total; //variable entier total

        String input1 = JOptionPane.showInputDialog("2+2 ="); // Affiche une pop up pour demander un nombre à l'utilisateur
        int resultat1 = Integer.parseInt(input1); // Convertit la chaîne de caractères saisie en entier
        
        String input2 = JOptionPane.showInputDialog("6+4 ="); // Affiche une pop up pour demander un nombre à l'utilisateur
        int resultat2 = Integer.parseInt(input2); // Convertit la chaîne de caractères saisie en entier

        total = 0; //initialisation de total a 0

        if (resultat1 == 4) { //si ...
            total = total + 10; //total + 10
        } 
        if (resultat2 == 10) { //si...
            total = total + 10; //total + 10
        }

        if (total == 20){ //si
            JOptionPane.showMessageDialog(null, "20/20 Bravo !"); // Affiche une pop up avec la phrase...
        } else if (total == 10){ //si
            JOptionPane.showMessageDialog(null, "10/20 Je crois que tu as compris l’essentiel…"); // Affiche une pop up avec la phrase...
        } else { //si
            JOptionPane.showMessageDialog(null, "0/20 Tu peux revoir ce chapitre ."); // Affiche une pop up avec la phrase...
        }
    }   
}
