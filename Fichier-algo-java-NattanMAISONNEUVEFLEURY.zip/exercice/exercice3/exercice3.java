package exercice3;

import java.util.Scanner;

public class exercice3 {
    public static void main(String[] args) {

        float a; //variable réel a
        float b; //variable réel b

        Scanner sc = new Scanner(System.in); //commande qui permet de faire écrire l'utilisateur et de garder en mémoire la réponse
        System.out.println("Entrer un nombre : "); //afficher la phrase ...
        a = sc.nextFloat(); //demande à l'utilisateur un nombre et l'enregistre dans la variable a
        System.out.println("Entrez un deuxième nombre : "); //afficher la phrase ...
        b = sc.nextFloat(); //demande à l'utilisateur un nombre et l'enregistre dans la variable b

        if ((a > 0 & b > 0) || (a < 0 & b < 0)){ //si a et b positif ou a et b négatif 
            System.out.println("Le produit est positif"); //afficher la phrase ...
        } else { //alors
            System.out.println("Le produit est négatif"); //afficher la phrase ...
        } //fin si
    }
}
