package exercice4;

import java.util.Scanner;

public class exercice4 {
    public static void main(String[] args) {
        int a; // variable entier a

        Scanner sc = new Scanner(System.in); //commande qui permet de faire écrire l'utilisateur et de garder en mémoire la réponse

        do{ //éxécuter ...
            System.out.println("Entrez un nombre"); //afficher la phrase ...
            a = sc.nextInt(); //demande à l'utilisateur un nombre et l'enregistre dans la variable a
            if (a < 10) { //si a < 10
                System.out.println("Plus grand"); //afficher la phrase ...
            } else if (a > 20) { //sinon si a > 20
                System.out.println("Plus petit"); //afficher la phrase ...
            } else { //sinon
                System.out.println("Bravo !"); //afficher la phrase ...
            } //fin si
        } while ((a < 10) || (a > 20)); //tant que a < 10 ou a > 20
    }
}
