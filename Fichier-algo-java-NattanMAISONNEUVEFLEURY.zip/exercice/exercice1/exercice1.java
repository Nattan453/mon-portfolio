package exercice1; 

import java.util.Scanner;

public class exercice1 {
public static void main(String[] args) {

    //Variables

    int a; //variable entier a
    int b; //variable entier b
    int c; //variable entier c

    //Code : 

    Scanner sc = new Scanner(System.in); //commande qui permet de faire écrire l'utilisateur et de garder en mémoire la réponse
    System.out.println("entrer a : "); //Affiche la phrase ...
    a = sc.nextInt(); //demande à l'utilisateur un nombre et l'enregistre dans la variable a
    System.out.println("entrez b : "); //Affiche la phrase ...
    b = sc.nextInt(); //demande à l'utilisateur un nombre et l'enregistre dans la variable b

    c = b; //la variable c prend la valeur de b
    b = a; //la variable b prend la valeur de a
    a = c; //la variable a prend la valeur de c

    System.out.println("a vaut " + a + " et b vaut " + b); //afficher le résultat
    }
}

