package exercice1bis;

import javax.swing.JOptionPane; // Importation de la classe JOptionPane

public class exercice1bis { 
    public static void main(String[] args) { 

        String input = JOptionPane.showInputDialog("Entrez un nombre"); // Affiche une pop up pour demander un nombre à l'utilisateur

        int a = Integer.parseInt(input); // Convertit la chaîne de caractères saisie en entier

        if (a >= 50 && a <= 100) { // Vérifie si le nombre est compris entre 50 et 100 inclus
            JOptionPane.showMessageDialog(null, "Le nombre est compris entre 50 et 100"); // Affiche une pop up avec la phrase...
        } else { //sinon
            JOptionPane.showMessageDialog(null, "Le nombre n'est pas compris entre 50 et 100"); //affiche une pop up avec la phrase ...
        }
    }
}
