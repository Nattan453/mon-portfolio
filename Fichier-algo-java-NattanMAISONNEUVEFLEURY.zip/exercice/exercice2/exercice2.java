package exercice2;

import java.util.Scanner;

public class exercice2 {
    public static void main(String[] args) {
        int a;

        Scanner sc = new Scanner(System.in); //commande qui permet de faire écrire l'utilisateur et de garder en mémoire la réponse
        System.out.println("Entrez un nombre");
        a = sc.nextInt();

        a = a*a;

        System.out.println("Le carré de votre nombre est : " + a);
    }
}
